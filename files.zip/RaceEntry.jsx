import { useState, useEffect } from "react";
import { useAuth } from "../App";
import { api, formatElapsed, parseTimeInput } from "../api";
import Modal from "../components/Modal";

const STATUS_OPTIONS = ["FIN", "DNF", "DNS", "DSQ", "DNC"];
const STATUS_COLORS = { FIN: "green", DNF: "orange", DNS: "gray", DSQ: "red", DNC: "gray" };

export default function RaceEntry({ seriesId, seriesName }) {
  const { user, navigate } = useAuth();
  const [races, setRaces] = useState([]);
  const [selectedRace, setSelectedRace] = useState(null);
  const [boats, setBoats] = useState([]);
  const [finishes, setFinishes] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showRaceModal, setShowRaceModal] = useState(false);
  const [editRace, setEditRace] = useState(null);
  const [raceForm, setRaceForm] = useState({ race_number: "", name: "", race_date: "" });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  // Inline time entry state: boatId -> { timeStr, status }
  const [entries, setEntries] = useState({});
  const [submitMsg, setSubmitMsg] = useState("");

  const loadRaces = () =>
    api.get(`/series/${seriesId}/races`, user.token).then(r => {
      setRaces(r);
      if (r.length > 0 && !selectedRace) setSelectedRace(r[r.length - 1]);
    }).finally(() => setLoading(false));

  const loadBoats = () =>
    api.get(`/series/${seriesId}/boats`, user.token).then(setBoats);

  useEffect(() => { loadRaces(); loadBoats(); }, [seriesId]);

  useEffect(() => {
    if (!selectedRace) return;
    loadFinishesAndResults();
  }, [selectedRace]);

  const loadFinishesAndResults = async () => {
    const [fins, res] = await Promise.all([
      api.get(`/races/${selectedRace.id}/finishes`, user.token),
      api.get(`/races/${selectedRace.id}/results`, user.token),
    ]);
    setFinishes(fins);
    setResults(res);

    // Populate entry state from existing finishes
    const map = {};
    fins.forEach(f => {
      const secs = f.elapsed_seconds;
      map[f.boat_id] = {
        timeStr: secs != null ? formatElapsed(secs) : "",
        status: f.status,
      };
    });
    setEntries(map);
  };

  const openNewRace = () => {
    const nextNum = races.length > 0 ? Math.max(...races.map(r => r.race_number)) + 1 : 1;
    setEditRace(null);
    setRaceForm({ race_number: nextNum, name: "", race_date: new Date().toISOString().split("T")[0] });
    setError("");
    setShowRaceModal(true);
  };

  const openEditRace = (r) => {
    setEditRace(r);
    setRaceForm({ race_number: r.race_number, name: r.name || "", race_date: r.race_date || "" });
    setError("");
    setShowRaceModal(true);
  };

  const saveRace = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const body = { ...raceForm, race_number: Number(raceForm.race_number) };
      let saved;
      if (editRace) {
        saved = await api.put(`/races/${editRace.id}`, body, user.token);
      } else {
        saved = await api.post(`/series/${seriesId}/races`, body, user.token);
      }
      setShowRaceModal(false);
      await loadRaces();
      setSelectedRace(saved);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const deleteRace = async (id) => {
    if (!confirm("Delete this race and all its finishes?")) return;
    await api.delete(`/races/${id}`, user.token);
    setSelectedRace(null);
    setFinishes([]);
    setResults([]);
    setEntries({});
    loadRaces();
  };

  const setEntry = (boatId, field, value) => {
    setEntries(prev => ({
      ...prev,
      [boatId]: { ...(prev[boatId] || { timeStr: "", status: "FIN" }), [field]: value }
    }));
  };

  const submitFinish = async (boatId) => {
    const entry = entries[boatId] || { timeStr: "", status: "DNS" };
    const status = entry.status || "FIN";
    let elapsed = null;

    if (status === "FIN") {
      elapsed = parseTimeInput(entry.timeStr);
      if (elapsed === null || elapsed <= 0) {
        setSubmitMsg(`Invalid time for boat ${boatId}`);
        return;
      }
    }

    try {
      await api.post(`/races/${selectedRace.id}/finishes`,
        { boat_id: boatId, elapsed_seconds: elapsed, status },
        user.token
      );
      await loadFinishesAndResults();
      setSubmitMsg("Saved ✓");
      setTimeout(() => setSubmitMsg(""), 2000);
    } catch (err) {
      setSubmitMsg("Error: " + err.message);
    }
  };

  const submitAll = async () => {
    setSaving(true);
    for (const boat of boats) {
      await submitFinish(boat.id);
    }
    setSaving(false);
  };

  // Build result lookup by boat_id
  const resultMap = {};
  results.forEach(r => { resultMap[r.boat_id] = r; });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <button className="breadcrumb" onClick={() => navigate("dashboard")}>← My Series</button>
          <h1 className="page-title">{seriesName}</h1>
          <p className="page-subtitle">Race Entry</p>
        </div>
        <div className="header-actions">
          <button className="btn-secondary" onClick={() => navigate("standings", { seriesId, seriesName })}>Standings →</button>
          <button className="btn-primary" onClick={openNewRace}>+ New Race</button>
        </div>
      </div>

      <div className="race-layout">
        {/* Race list sidebar */}
        <div className="race-sidebar">
          <div className="sidebar-title">Races</div>
          {loading ? <div className="spinner" /> : races.length === 0 ? (
            <div className="sidebar-empty">No races yet</div>
          ) : (
            races.map(r => (
              <button
                key={r.id}
                className={`race-tab ${selectedRace?.id === r.id ? "active" : ""}`}
                onClick={() => setSelectedRace(r)}
              >
                <span className="race-tab-num">R{r.race_number}</span>
                <span className="race-tab-detail">
                  {r.name || r.race_date || "—"}
                </span>
              </button>
            ))
          )}
        </div>

        {/* Main entry area */}
        <div className="race-main">
          {!selectedRace ? (
            <div className="empty-state">
              <div className="empty-icon">🏁</div>
              <h3>Select or create a race</h3>
              <button className="btn-primary" onClick={openNewRace}>Create First Race</button>
            </div>
          ) : (
            <>
              <div className="race-entry-header">
                <div>
                  <h2 className="race-title">
                    Race {selectedRace.race_number}
                    {selectedRace.name && <span className="race-name-sub"> — {selectedRace.name}</span>}
                  </h2>
                  {selectedRace.race_date && (
                    <span className="race-date">{selectedRace.race_date}</span>
                  )}
                </div>
                <div className="race-entry-actions">
                  <button className="btn-ghost-sm" onClick={() => openEditRace(selectedRace)}>Edit</button>
                  <button className="btn-ghost-sm danger" onClick={() => deleteRace(selectedRace.id)}>Delete</button>
                </div>
              </div>

              {boats.length === 0 ? (
                <div className="empty-state small">
                  <p>No boats in fleet yet. <button className="link-btn" onClick={() => navigate("fleet", { seriesId, seriesName })}>Add boats</button> first.</p>
                </div>
              ) : (
                <>
                  <div className="entry-table-wrap">
                    <table className="entry-table">
                      <thead>
                        <tr>
                          <th>Sail #</th>
                          <th>Boat / Skipper</th>
                          <th>PHRF</th>
                          <th>Status</th>
                          <th>Elapsed (H:MM:SS)</th>
                          <th>Corrected</th>
                          <th>Position</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {boats.map(boat => {
                          const entry = entries[boat.id] || { timeStr: "", status: "FIN" };
                          const result = resultMap[boat.id];
                          const isFin = entry.status === "FIN";
                          return (
                            <tr key={boat.id} className={result ? "has-result" : ""}>
                              <td><span className="sail-num">{boat.sail_number}</span></td>
                              <td>
                                <div className="boat-cell">
                                  <span className="boat-name">{boat.boat_name}</span>
                                  <span className="skipper-name">{boat.skipper}</span>
                                </div>
                              </td>
                              <td className="num-col">{boat.phrf_rating}</td>
                              <td>
                                <select
                                  className={`status-select status-${STATUS_COLORS[entry.status] || "gray"}`}
                                  value={entry.status || "FIN"}
                                  onChange={e => setEntry(boat.id, "status", e.target.value)}
                                >
                                  {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                              </td>
                              <td>
                                {isFin ? (
                                  <input
                                    className="time-input"
                                    type="text"
                                    placeholder="1:23:45"
                                    value={entry.timeStr}
                                    onChange={e => setEntry(boat.id, "timeStr", e.target.value)}
                                    onKeyDown={e => e.key === "Enter" && submitFinish(boat.id)}
                                  />
                                ) : (
                                  <span className="na-text">—</span>
                                )}
                              </td>
                              <td className="num-col mono">
                                {result?.corrected_display || (result?.status !== "FIN" ? "—" : "")}
                              </td>
                              <td className="num-col">
                                {result?.position != null ? (
                                  <span className={`pos-badge pos-${result.position}`}>
                                    {result.position === 1 ? "🥇" : result.position === 2 ? "🥈" : result.position === 3 ? "🥉" : `${result.position}th`}
                                  </span>
                                ) : result?.status !== "FIN" ? (
                                  <span className={`status-pill status-${STATUS_COLORS[result?.status] || "gray"}`}>
                                    {result?.status}
                                  </span>
                                ) : "—"}
                              </td>
                              <td>
                                <button className="btn-save" onClick={() => submitFinish(boat.id)}>Save</button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  <div className="entry-footer">
                    {submitMsg && <span className="save-msg">{submitMsg}</span>}
                    <button className="btn-primary" onClick={submitAll} disabled={saving}>
                      {saving ? "Saving all..." : "Save All"}
                    </button>
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </div>

      {showRaceModal && (
        <Modal title={editRace ? "Edit Race" : "New Race"} onClose={() => setShowRaceModal(false)}>
          <form onSubmit={saveRace}>
            <div className="field-row">
              <div className="field">
                <label>Race Number</label>
                <input type="number" min="1" value={raceForm.race_number}
                  onChange={e => setRaceForm({ ...raceForm, race_number: e.target.value })} required />
              </div>
              <div className="field">
                <label>Date</label>
                <input type="date" value={raceForm.race_date}
                  onChange={e => setRaceForm({ ...raceForm, race_date: e.target.value })} />
              </div>
            </div>
            <div className="field">
              <label>Race Name (optional)</label>
              <input type="text" placeholder="e.g. Spinnaker Race" value={raceForm.name}
                onChange={e => setRaceForm({ ...raceForm, name: e.target.value })} />
            </div>
            {error && <div className="form-error">{error}</div>}
            <div className="modal-footer">
              <button type="button" className="btn-ghost" onClick={() => setShowRaceModal(false)}>Cancel</button>
              <button type="submit" className="btn-primary" disabled={saving}>
                {saving ? "Saving..." : editRace ? "Save Changes" : "Create Race"}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
